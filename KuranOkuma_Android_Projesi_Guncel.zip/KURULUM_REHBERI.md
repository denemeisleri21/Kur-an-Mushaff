# Kur'an-ı Kerim Mushaf Okuma — Android Projesi ve Otomatik APK Derleme Rehberi

Bu proje, Diyanet Mushafı sayfa düzenine tam uyumlu, yüksek çözünürlüklü ve kesintisiz Kur'an-ı Kerim okuma deneyimi sunan **yerel Android (Kotlin)** uygulamasıdır.

---

### ✨ Projede Yer Alan Önemli Özellikler

1. **📱 Gerçek Tam Ekran & Saf İmmersive Okuma Modu (Yeni Eklendi):**
   - Ekranın ortasına dokunulduğunda telefonun **üst durum çubuğu (şebeke bilgisi, operatör, pil, saat, Wi-Fi)** ve **alt takım gezinme tuşları (Geri, Ana Sayfa, Son Uygulamalar)** tamamen gizlenir.
   - Kamera deliği / ekran çentiği (Display Cutout / Notch) alanları da dahil olmak üzere ekranın her bir pikseli saf Mushaf sayfasına ayrılır.
   - Okuma sırasında sayfayı aşağı-yukarı kaydırırken veya yakınlaştırırken alt takım tuşları ekrana geri gelmez (`IMMERSIVE_STICKY` ve `BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE`).
   - Ekranın ortasına tekrar dokunulduğunda üst ve alt kontrol menüleriyle birlikte sistem çubukları yumuşak bir animasyonla geri gelir.
   - Uygulama arka plana atılıp tekrar açıldığında veya odak değiştiğinde tam ekran modu bozulmadan korunur.

2. **🔍 Gelişmiş Yakınlaştırma (Pinch-to-Zoom & Çift Dokunma & `+ / −` Butonları):**
   - İki parmakla kıstırıp açarak, ekrana çift dokunarak veya alt çubuktaki butonlarla sayfayı %100 ile %320 arasında büyütebilirsiniz (`ZoomableRecyclerView.kt`).

3. **🔒 Yatay Kaymayı Kilitleyen Tuş (`🔒 Yatay Kilitli`):**
   - Sayfa büyütüldükten sonra sayfa hizanızın bozulmaması için sağ alttaki kilit tuşuna basarak yatay kaymayı kilitleyebilir, sadece aşağı-yukarı akıcı şekilde okuyabilirsiniz. Menü gizlendiğinde kilit tuşu da ekrandan gizlenir.

4. **🖼️ Özel Mushaf Uygulama İkonu:**
   - Gönderdiğiniz yeşil sarmaşıklar arasındaki Mushaf görseli, Android 8+ Adaptive Icon (`mipmap-anydpi-v26`) ve tüm standart çözünürlükler (`mdpi` .. `xxxhdpi`) için optimize edilmiş olarak projeye entegre edilmiştir.

5. **🌙 Gece Modu & Sure/Cüz Listesi & Kaldığınız Yeri Hatırlama:**
   - Göz yormayan koyu zemin modu, 114 Sure ve 30 Cüz fihristi, anlık arama ve otomatik son kalınan sayfaya yönlendirme özellikleri hazır durumdadır.

---

### 🚀 GitHub'a Yükleyip Otomatik APK Alma Adımları

Projenin içinde GitHub Actions iş akışı (`.github/workflows/build-apk.yml`) hazır olarak yapılandırılmıştır. Hiçbir Android Studio veya Gradle kurulumu yapmadan doğrudan GitHub üzerinden APK alabilirsiniz:

1. **GitHub'da Yeni Bir Depo (Repository) Oluşturun:**
   - [GitHub.com](https://github.com)'a giriş yapın.
   - Sağ üstteki **`+`** simgesine tıklayıp **"New repository"** seçin.
   - Deponuza bir isim verin (Örn: `kuran-mushaf-okuma`) ve **"Create repository"** butonuna basın.

2. **Proje Dosyalarını GitHub'a Yükleyin:**
   - Size iletilen zip dosyasını bilgisayarınızda bir klasöre çıkarın.
   - GitHub depo sayfanızda **"uploading an existing file"** linkine tıklayın.
   - Klasörün içindeki tüm dosya ve klasörleri (`app`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `KURULUM_REHBERI.md`) sürükleyip GitHub yükleme alanına bırakın.
   - Sayfanın altındaki **"Commit changes"** butonuna basarak yüklemeyi tamamlayın.
   *(Eğer Git komut satırı kullanıyorsanız: `git init`, `git add .`, `git commit -m "Tam ekran guncellemesi"`, `git branch -M main`, `git remote add origin <repo_link>`, `git push -u origin main`)*

3. **Otomatik APK Derleme Süreci:**
   - Dosyalar yüklendiği anda GitHub'ın üst menüsündeki **"Actions"** sekmesinde derleme işlemi otomatik olarak başlayacaktır (`Android APK Derle`).
   - Bu işlem bulut sunucularda yaklaşık 2-3 dakika sürer ve bittiğinde yeşil onay işareti (`✓`) görünür.

4. **Hazır APK'yı İndirme:**
   - **Actions** sekmesinde tamamlanan işe (örneğin son commit başlığına) tıklayın.
   - Sayfanın en altındaki **"Artifacts"** (Çıktılar) bölümünde **`Kuran-Mushaf-Okuma-APK`** dosyasını göreceksiniz.
   - Üzerine tıklayarak hazır `app-debug.apk` dosyasını bilgisayarınıza veya doğrudan telefonunuza indirip kurabilirsiniz.
