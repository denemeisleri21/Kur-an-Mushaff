package com.kuranokuma.mushaf

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var pdfRecyclerView: ZoomableRecyclerView
    private lateinit var layoutManager: LinearLayoutManager

    private lateinit var topAppBar: LinearLayout
    private lateinit var bottomControlBar: LinearLayout
    private lateinit var horizontalLockButton: Button

    private lateinit var topSurahTitle: TextView
    private lateinit var topPageSubtitle: TextView
    private lateinit var bookmarkButton: Button
    private lateinit var pageSeekBar: SeekBar
    private lateinit var zoomLevelText: TextView
    private lateinit var nightModeBtn: Button

    // Yan Menü (Drawer) Bileşenleri
    private lateinit var drawerLastReadInfo: TextView
    private lateinit var resumeLastPlaceBtn: Button
    private lateinit var tabSurahsBtn: Button
    private lateinit var tabJuzsBtn: Button
    private lateinit var tabBookmarksBtn: Button
    private lateinit var tabSettingsBtn: Button
    private lateinit var drawerSearchInput: EditText
    private lateinit var drawerListView: ListView
    private lateinit var drawerSettingsContainer: ScrollView

    // Ayarlar Anahtarları (Switches)
    private lateinit var switchPageHeaders: Switch
    private lateinit var switchSeamlessReading: Switch
    private lateinit var switchFullscreenPure: Switch
    private lateinit var switchNightModeSetting: Switch

    private var pdfRenderer: PdfRenderer? = null
    private var parcelFileDescriptor: ParcelFileDescriptor? = null
    private var pdfAdapter: UltraHdPdfPageAdapter? = null
    private val renderLock = Any()

    private var currentPdfPage: Int = 2 // Varsayılan: Fâtiha Suresi (Mushaf Sayfa 1)
    private var isMenuVisible: Boolean = false
    private var activeTab: String = "surahs" // "surahs" | "juzs" | "bookmarks" | "settings"
    private val bookmarks = mutableListOf<BookmarkItem>()
    private var currentListTargets = mutableListOf<Any>()

    private var showPageHeaders: Boolean = false
    private var seamlessReading: Boolean = true
    private var fullscreenPure: Boolean = true
    private var isNightMode: Boolean = false

    // Ekran döndürme (Dikey <-> Yatay) sırasında sayfa oranını ve okunan satır konumunu koruma değişkenleri
    private var lastAppliedViewportWidth: Int = 0
    private var pendingRotationPage: Int = RecyclerView.NO_POSITION
    private var pendingRotationFraction: Float = 0f

    private val prefs by lazy {
        getSharedPreferences("kuran_mushaf_prefs_v1", Context.MODE_PRIVATE)
    }

    private val openPdfLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            copyExternalPdfAndOpen(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Uçtan uca (Edge-to-Edge) ekran yerleşimi: İçeriğin sistem çubuklarının altına kadar pürüzsüz uzanması
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // 2. Ekran çentiği (Notch) ve kamera deliği alanlarına kadar tam ekran yayılım (Android 9+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        // 3. Şeffaf durum ve gezinme çubukları (arkada siyah şerit kalmasını engeller)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }

        setContentView(R.layout.activity_main)

        bindViews()
        loadPreferences()
        setupControls()
        openBundledOrCachedPdf()
    }

    private fun bindViews() {
        drawerLayout = findViewById(R.id.drawerLayout)
        pdfRecyclerView = findViewById(R.id.pdfRecyclerView)
        topAppBar = findViewById(R.id.topAppBar)
        bottomControlBar = findViewById(R.id.bottomControlBar)
        horizontalLockButton = findViewById(R.id.horizontalLockButton)

        topSurahTitle = findViewById(R.id.topSurahTitle)
        topPageSubtitle = findViewById(R.id.topPageSubtitle)
        bookmarkButton = findViewById(R.id.bookmarkButton)
        pageSeekBar = findViewById(R.id.pageSeekBar)
        zoomLevelText = findViewById(R.id.zoomLevelText)
        nightModeBtn = findViewById(R.id.nightModeBtn)

        drawerLastReadInfo = findViewById(R.id.drawerLastReadInfo)
        resumeLastPlaceBtn = findViewById(R.id.resumeLastPlaceBtn)
        tabSurahsBtn = findViewById(R.id.tabSurahsBtn)
        tabJuzsBtn = findViewById(R.id.tabJuzsBtn)
        tabBookmarksBtn = findViewById(R.id.tabBookmarksBtn)
        tabSettingsBtn = findViewById(R.id.tabSettingsBtn)
        drawerSearchInput = findViewById(R.id.drawerSearchInput)
        drawerListView = findViewById(R.id.drawerListView)
        drawerSettingsContainer = findViewById(R.id.drawerSettingsContainer)

        switchPageHeaders = findViewById(R.id.switchPageHeaders)
        switchSeamlessReading = findViewById(R.id.switchSeamlessReading)
        switchFullscreenPure = findViewById(R.id.switchFullscreenPure)
        switchNightModeSetting = findViewById(R.id.switchNightModeSetting)

        layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        pdfRecyclerView.layoutManager = layoutManager
        pdfRecyclerView.itemAnimator = null
        pdfRecyclerView.setItemViewCacheSize(8)
        pdfRecyclerView.setHasFixedSize(false)
        pdfRecyclerView.setPadding(0, 0, 0, 0)

        // Sayfaların yanlarındaki ve aralarındaki tüm boşlukları sıfırla ve her eklenen görünümde gerçek ekran genişliğine göre boyutu doğrula
        pdfRecyclerView.addOnChildAttachStateChangeListener(object : RecyclerView.OnChildAttachStateChangeListener {
            override fun onChildViewAttachedToWindow(view: View) {
                stripPageFollowMargins(view)
                val vh = pdfRecyclerView.getChildViewHolder(view) as? UltraHdPdfPageAdapter.PageViewHolder
                if (vh != null) {
                    val liveW = pdfRecyclerView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
                    pdfAdapter?.syncHolderDimensions(vh, liveW)
                }
            }
            override fun onChildViewDetachedFromWindow(view: View) {}
        })

        // Ekran yatay/dikey döndürüldüğünde RecyclerView'ın gerçek genişliği değiştiği anda sayfaları yeniden boyutlandır
        pdfRecyclerView.onViewportSizeChanged = { newW, _ ->
            onViewportWidthUpdated(newW)
        }

        pdfRecyclerView.addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
            val newW = right - left
            val oldW = oldRight - oldLeft
            if (newW > 0 && newW != oldW) {
                onViewportWidthUpdated(newW)
            }
        }

        // Yatay kilit tuşunun alt menünün altında kalmasını engelle (her zaman en üstte ve menünün üstünde)
        horizontalLockButton.bringToFront()
        horizontalLockButton.elevation = dpToPx(24).toFloat()
        horizontalLockButton.translationZ = dpToPx(24).toFloat()
        (horizontalLockButton.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.bottomMargin = dpToPx(118)
            horizontalLockButton.layoutParams = lp
        }
        bottomControlBar.addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
            val barHeight = bottom - top
            if (barHeight > 0) {
                (horizontalLockButton.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
                    val targetBottom = barHeight + dpToPx(12)
                    if (lp.bottomMargin != targetBottom) {
                        lp.bottomMargin = targetBottom
                        horizontalLockButton.layoutParams = lp
                    }
                }
            }
        }
    }

    private fun captureReadingPositionBeforeResize() {
        val firstPos = layoutManager.findFirstVisibleItemPosition()
        if (firstPos != RecyclerView.NO_POSITION) {
            val child = layoutManager.findViewByPosition(firstPos)
            pendingRotationPage = firstPos
            pendingRotationFraction = if (child != null && child.height > 0) {
                (-child.top.toFloat() / child.height.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }
        }
    }

    private fun onViewportWidthUpdated(newW: Int) {
        if (newW <= 0 || newW == lastAppliedViewportWidth) return

        val targetPos = if (pendingRotationPage != RecyclerView.NO_POSITION) {
            pendingRotationPage
        } else {
            layoutManager.findFirstVisibleItemPosition().takeIf { it != RecyclerView.NO_POSITION }
                ?: (currentPdfPage - 1).coerceAtLeast(0)
        }
        val targetFraction = if (pendingRotationPage != RecyclerView.NO_POSITION) {
            pendingRotationFraction
        } else {
            val child = layoutManager.findViewByPosition(targetPos)
            if (child != null && child.height > 0) {
                (-child.top.toFloat() / child.height.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }
        }

        lastAppliedViewportWidth = newW
        pendingRotationPage = RecyclerView.NO_POSITION

        pdfAdapter?.let { adapter ->
            adapter.updateViewportWidth(newW, pdfRecyclerView)
            pdfRecyclerView.post {
                adapter.updateViewportWidth(newW, pdfRecyclerView)
                if (adapter.itemCount > 0) {
                    val safePos = targetPos.coerceIn(0, adapter.itemCount - 1)
                    val newPageHeight = adapter.getExpectedPageHeight(safePos, newW)
                    val newOffset = -(newPageHeight * targetFraction).roundToInt()
                    layoutManager.scrollToPositionWithOffset(safePos, newOffset)
                }
            }
        }
    }

    private fun stripPageFollowMargins(view: View) {
        val pageBg = if (isNightMode) Color.parseColor("#141816") else Color.parseColor("#FFF1D1")
        view.setPadding(0, 0, 0, 0)
        view.setBackgroundColor(pageBg)
        (view.layoutParams as? RecyclerView.LayoutParams)?.let { lp ->
            if (lp.leftMargin != 0 || lp.rightMargin != 0 || lp.topMargin != 0 || lp.bottomMargin != 0) {
                lp.setMargins(0, 0, 0, 0)
                view.layoutParams = lp
            }
        }
        view.findViewById<View>(R.id.pageSeamlessDivider)?.visibility = View.GONE
        view.findViewById<View>(R.id.pageImageView)?.let { img ->
            img.setBackgroundColor(pageBg)
            (img.parent as? View)?.let { parentFrame ->
                parentFrame.setPadding(0, 0, 0, 0)
                parentFrame.setBackgroundColor(pageBg)
            }
        }
    }

    private fun setupControls() {
        // Yan menü (Drawer) açıldığında veya kapandığında sistem çubuklarını her zaman gizli tut
        drawerLayout.addDrawerListener(object : DrawerLayout.SimpleDrawerListener() {
            override fun onDrawerOpened(drawerView: View) {
                hideSystemBars()
            }
            override fun onDrawerClosed(drawerView: View) {
                hideSystemBars()
            }
            override fun onDrawerStateChanged(newState: Int) {
                hideSystemBars()
            }
        })

        // İlk açılışta sistem çubuklarını (şebeke bilgisi ve alt takım tuşları) tamamen gizle
        hideSystemBars()
        window.decorView.post {
            hideSystemBars()
        }

        // Ekranın ortasına tek tıklama: Üst, Alt ve Yüzen Kilit tuşlarını gizle/göster (Tam Ekran Modu)
        pdfRecyclerView.onCenterSingleTap = {
            toggleFullScreenMenu()
        }

        pdfRecyclerView.onZoomChanged = { scale ->
            val pct = (scale * 100).toInt()
            zoomLevelText.text = "$pct%"
        }

        // Yanlara kaymayı kilitleyen yüzen tuş
        updateHorizontalLockUi(pdfRecyclerView.isHorizontalPanLocked, showToastMsg = false)
        horizontalLockButton.setOnClickListener {
            val newLockState = !pdfRecyclerView.isHorizontalPanLocked
            pdfRecyclerView.isHorizontalPanLocked = newLockState
            prefs.edit().putBoolean("horizontal_pan_locked", newLockState).apply()
            updateHorizontalLockUi(newLockState, showToastMsg = true)
        }

        // Dikey kaydırma sırasında mevcut sayfayı takip et ve otomatik kaydet
        pdfRecyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val pos = layoutManager.findFirstVisibleItemPosition()
                if (pos != RecyclerView.NO_POSITION) {
                    val pageNum = pos + 1
                    if (pageNum != currentPdfPage) {
                        currentPdfPage = pageNum
                        updateTopAndBottomBar(currentPdfPage)
                        saveLastReadPage(currentPdfPage)
                    }
                }
            }
        })

        // Üst Çubuk Butonları
        findViewById<Button>(R.id.menuButton).setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
            populateDrawerList()
        }

        findViewById<LinearLayout>(R.id.headerInfoArea).setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
            populateDrawerList()
        }

        findViewById<Button>(R.id.selectExternalPdfButton).setOnClickListener {
            openPdfLauncher.launch(arrayOf("application/pdf"))
        }

        bookmarkButton.setOnClickListener {
            showAddBookmarkDialog()
        }

        // Alt Çubuk Butonları
        findViewById<Button>(R.id.prevPageButton).setOnClickListener {
            if (currentPdfPage > 1) {
                scrollToPdfPage(currentPdfPage - 1)
            }
        }

        findViewById<Button>(R.id.nextPageButton).setOnClickListener {
            val maxP = pdfRenderer?.pageCount ?: 616
            if (currentPdfPage < maxP) {
                scrollToPdfPage(currentPdfPage + 1)
            }
        }

        pageSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val targetPdf = MushafCatalog.mushafPageToPdfPage(progress.coerceAtLeast(1))
                    scrollToPdfPage(targetPdf)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<Button>(R.id.goToPageButton).setOnClickListener {
            showGoToPageDialog()
        }

        findViewById<Button>(R.id.zoomOutButton).setOnClickListener {
            pdfRecyclerView.stepZoom(-0.25f)
        }

        findViewById<Button>(R.id.zoomInButton).setOnClickListener {
            pdfRecyclerView.stepZoom(0.25f)
        }

        nightModeBtn.setOnClickListener {
            setNightModeEnabled(!isNightMode)
        }

        // Çekmece (Drawer) Son Kalınan Yer Butonu
        val goLastReadAction = View.OnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            scrollToPdfPage(currentPdfPage)
        }
        drawerLastReadInfo.setOnClickListener(goLastReadAction)
        resumeLastPlaceBtn.setOnClickListener(goLastReadAction)

        // Çekmece Sekmeleri (Sureler | Cüzler | Yer İmleri | Ayarlar)
        tabSurahsBtn.setOnClickListener { switchDrawerTab("surahs") }
        tabJuzsBtn.setOnClickListener { switchDrawerTab("juzs") }
        tabBookmarksBtn.setOnClickListener { switchDrawerTab("bookmarks") }
        tabSettingsBtn.setOnClickListener { switchDrawerTab("settings") }

        drawerSearchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                populateDrawerList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        drawerListView.setOnItemClickListener { _, _, position, _ ->
            val item = currentListTargets.getOrNull(position) ?: return@setOnItemClickListener
            when (item) {
                is SurahItem -> {
                    drawerLayout.closeDrawer(GravityCompat.START)
                    scrollToPdfPage(item.pdfPage)
                    Toast.makeText(this, "${item.name} Suresi (Sayfa ${item.mushafPage}) açıldı", Toast.LENGTH_SHORT).show()
                }
                is JuzItem -> {
                    drawerLayout.closeDrawer(GravityCompat.START)
                    scrollToPdfPage(item.pdfPage)
                    Toast.makeText(this, "${item.juz}. Cüz (Sayfa ${item.mushafPage}) açıldı", Toast.LENGTH_SHORT).show()
                }
                is BookmarkItem -> {
                    drawerLayout.closeDrawer(GravityCompat.START)
                    scrollToPdfPage(item.pdfPage)
                    Toast.makeText(this, "${item.note} açıldı", Toast.LENGTH_SHORT).show()
                }
            }
        }

        drawerListView.setOnItemLongClickListener { _, _, position, _ ->
            val item = currentListTargets.getOrNull(position)
            if (item is BookmarkItem) {
                AlertDialog.Builder(this)
                    .setTitle("Yer İmini Sil")
                    .setMessage("'${item.note}' yer imini silmek istiyor musunuz?")
                    .setPositiveButton("Sil") { _, _ ->
                        bookmarks.remove(item)
                        saveBookmarksToPrefs()
                        populateDrawerList()
                        updateTopAndBottomBar(currentPdfPage)
                    }
                    .setNegativeButton("İptal", null)
                    .show()
                true
            } else {
                false
            }
        }

        // Ayarlar Anahtarları Dinleyicileri
        switchPageHeaders.setOnCheckedChangeListener { _, isChecked ->
            showPageHeaders = isChecked
            prefs.edit().putBoolean("show_page_headers", isChecked).apply()
            applyAdapterDisplaySettings()
        }

        switchSeamlessReading.setOnCheckedChangeListener { _, isChecked ->
            seamlessReading = isChecked
            prefs.edit().putBoolean("seamless_reading", isChecked).apply()
            applyAdapterDisplaySettings()
        }

        switchFullscreenPure.setOnCheckedChangeListener { _, isChecked ->
            fullscreenPure = isChecked
            prefs.edit().putBoolean("fullscreen_pure", isChecked).apply()
            applyAdapterDisplaySettings()
        }

        switchNightModeSetting.setOnCheckedChangeListener { _, isChecked ->
            if (isNightMode != isChecked) {
                setNightModeEnabled(isChecked)
            }
        }
    }

    private fun setNightModeEnabled(enabled: Boolean) {
        isNightMode = enabled
        prefs.edit().putBoolean("night_mode", isNightMode).apply()
        if (switchNightModeSetting.isChecked != isNightMode) {
            switchNightModeSetting.isChecked = isNightMode
        }
        nightModeBtn.text = if (isNightMode) "🌙 Gece" else "📜 Orijinal"
        pdfRecyclerView.setBackgroundColor(
            if (isNightMode) Color.parseColor("#141816") else Color.parseColor("#FFF1D1")
        )
        applyAdapterDisplaySettings()
    }

    private fun applyAdapterDisplaySettings() {
        pdfAdapter?.let { adapter ->
            adapter.showPageHeaders = showPageHeaders
            adapter.seamlessReading = seamlessReading
            adapter.isFullscreen = !isMenuVisible
            adapter.fullscreenPure = fullscreenPure
            adapter.isNightMode = isNightMode
            adapter.notifyDataSetChanged()
        }
    }

    private fun openBundledOrCachedPdf() {
        try {
            val cachedPdfFile = File(filesDir, "kuran_mushaf_cached.pdf")
            if (!cachedPdfFile.exists() || cachedPdfFile.length() < 100_000L) {
                assets.open("kuran.pdf").use { input ->
                    FileOutputStream(cachedPdfFile).use { output ->
                        input.copyTo(output)
                    }
                }
            }
            loadPdfFile(cachedPdfFile)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "kuran.pdf yüklenemedi. Lütfen üstteki 📂 PDF butonundan kuran.pdf dosyasını seçin.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun copyExternalPdfAndOpen(uri: Uri) {
        try {
            val destFile = File(filesDir, "kuran_mushaf_cached.pdf")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            loadPdfFile(destFile)
            Toast.makeText(this, "Mushaf PDF dosyası kaydedildi ve açıldı!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "PDF dosyası açılamadı: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadPdfFile(file: File) {
        synchronized(renderLock) {
            pdfAdapter?.shutdown()
            try {
                pdfRenderer?.close()
                parcelFileDescriptor?.close()
            } catch (_: Exception) {}

            parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pdfRenderer = PdfRenderer(parcelFileDescriptor!!)
        }

        val initialWidth = pdfRecyclerView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        lastAppliedViewportWidth = initialWidth

        val adapter = UltraHdPdfPageAdapter(pdfRenderer!!, renderLock)
        adapter.showPageHeaders = showPageHeaders
        adapter.seamlessReading = seamlessReading
        adapter.isFullscreen = !isMenuVisible
        adapter.fullscreenPure = fullscreenPure
        adapter.isNightMode = isNightMode
        pdfAdapter = adapter
        pdfRecyclerView.adapter = adapter

        pdfRecyclerView.setBackgroundColor(
            if (isNightMode) Color.parseColor("#141816") else Color.parseColor("#FFF1D1")
        )

        val targetPage = currentPdfPage.coerceIn(1, pdfRenderer!!.pageCount)
        scrollToPdfPage(targetPage)
        val meta = MushafCatalog.getPageMeta(targetPage)
        Toast.makeText(
            this,
            "Son kalınan sayfa açıldı: ${meta.mushafPageLabel} (${meta.surahTitle})",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun scrollToPdfPage(pdfPage: Int) {
        val count = pdfRenderer?.pageCount ?: 616
        val clamped = pdfPage.coerceIn(1, count)
        currentPdfPage = clamped
        layoutManager.scrollToPositionWithOffset(clamped - 1, 0)
        updateTopAndBottomBar(clamped)
        saveLastReadPage(clamped)
    }

    private fun updateTopAndBottomBar(pdfPage: Int) {
        val meta = MushafCatalog.getPageMeta(pdfPage)
        topSurahTitle.text = meta.surahTitle
        topPageSubtitle.text = "${meta.mushafPageLabel} • ${meta.juzLabel}"
        drawerLastReadInfo.text = "${meta.mushafPageLabel} • ${meta.surahTitle} (${meta.juzLabel})"

        val mushafNo = meta.mushafPage.coerceIn(1, 604)
        if (pageSeekBar.progress != mushafNo) {
            pageSeekBar.progress = mushafNo
        }

        val isMarked = bookmarks.any { it.pdfPage == pdfPage }
        bookmarkButton.text = if (isMarked) "★ İşaretli" else "☆ İşaretle"
    }

    private fun toggleFullScreenMenu() {
        isMenuVisible = !isMenuVisible
        prefs.edit().putBoolean("menu_visible", isMenuVisible).apply()
        if (isMenuVisible) {
            topAppBar.visibility = View.VISIBLE
            bottomControlBar.visibility = View.VISIBLE
            horizontalLockButton.visibility = View.VISIBLE
            horizontalLockButton.bringToFront()
        } else {
            topAppBar.visibility = View.GONE
            bottomControlBar.visibility = View.GONE
            horizontalLockButton.visibility = View.GONE
        }
        // Menü açıldığında da şebeke bilgisi ve alt tuşlar görünmesin, sayfa yeniden yüklenmesin
        hideSystemBars()
    }

    private fun hideSystemBars() {
        // 1. Ekran çentiği (Notch / Kamera deliği) alanına kadar tam ekran yayılma
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        // 2. WindowManager Fullscreen bayrağı (Durum çubuğunu, şebeke/pil/saat ikonlarını kesin olarak gizler)
        @Suppress("DEPRECATION")
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

        // 3. AndroidX WindowInsetsControllerCompat ile modern ve tüm sürümlere uyumlu gizleme
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())

        // 4. Eski ve üreticiye özel (Samsung, Xiaomi vb.) Android sürümleri için Immersive Sticky bayrakları
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LOW_PROFILE
        )
    }

    private fun showSystemBars() {
        @Suppress("DEPRECATION")
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())

        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemBars()
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        window.decorView.post {
            hideSystemBars()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        captureReadingPositionBeforeResize()
        super.onConfigurationChanged(newConfig)
        hideSystemBars()

        val dmWidth = resources.displayMetrics.widthPixels
        if (dmWidth > 0 && dmWidth != lastAppliedViewportWidth) {
            onViewportWidthUpdated(dmWidth)
        }

        pdfRecyclerView.post {
            hideSystemBars()
            val actualW = pdfRecyclerView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
            if (actualW > 0) {
                if (actualW != lastAppliedViewportWidth) {
                    onViewportWidthUpdated(actualW)
                } else {
                    pdfAdapter?.updateViewportWidth(actualW, pdfRecyclerView)
                }
            }
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    private fun updateHorizontalLockUi(locked: Boolean, showToastMsg: Boolean) {
        if (locked) {
            horizontalLockButton.text = "🔒 Yatay Kilitli"
            horizontalLockButton.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
            horizontalLockButton.setTextColor(Color.parseColor("#07140E"))
            if (showToastMsg) {
                Toast.makeText(
                    this,
                    "Yatay kayma kilitlendi (Düzen bozulmadan aşağı-yukarı okuyabilirsiniz)",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            horizontalLockButton.text = "🔓 Yatay Serbest"
            horizontalLockButton.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#184332"))
            horizontalLockButton.setTextColor(Color.parseColor("#FDE68A"))
            if (showToastMsg) {
                Toast.makeText(
                    this,
                    "Yatay kayma kilidi açıldı (Yakınlaşınca sağa-sola gezinebilirsiniz)",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun switchDrawerTab(tab: String) {
        activeTab = tab
        val activeBg = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
        val inactiveBg = ColorStateList.valueOf(Color.parseColor("#0C2118"))
        val activeText = Color.parseColor("#07140E")
        val inactiveText = Color.parseColor("#A7F3D0")

        listOf(
            "surahs" to tabSurahsBtn,
            "juzs" to tabJuzsBtn,
            "bookmarks" to tabBookmarksBtn,
            "settings" to tabSettingsBtn
        ).forEach { (key, btn) ->
            if (key == tab) {
                btn.backgroundTintList = activeBg
                btn.setTextColor(activeText)
            } else {
                btn.backgroundTintList = inactiveBg
                btn.setTextColor(inactiveText)
            }
        }

        if (tab == "settings") {
            drawerSearchInput.visibility = View.GONE
            drawerListView.visibility = View.GONE
            drawerSettingsContainer.visibility = View.VISIBLE
        } else {
            drawerSettingsContainer.visibility = View.GONE
            drawerSearchInput.visibility = View.VISIBLE
            drawerListView.visibility = View.VISIBLE
            populateDrawerList()
        }
    }

    private fun populateDrawerList() {
        if (activeTab == "settings") return
        val q = drawerSearchInput.text?.toString()?.trim()?.lowercase(Locale("tr", "TR")) ?: ""
        currentListTargets.clear()
        val displayRows = mutableListOf<String>()

        when (activeTab) {
            "surahs" -> {
                MushafCatalog.SURAHS.filter {
                    q.isEmpty() ||
                        it.no.toString().contains(q) ||
                        it.name.lowercase(Locale("tr", "TR")).contains(q) ||
                        it.mushafPage.toString().contains(q)
                }.forEach { s ->
                    currentListTargets.add(s)
                    displayRows.add("${s.no}. ${s.name} Suresi (${s.arabic})\n${s.juz}. Cüz • ${s.ayetCount} Ayet • Mushaf Sayfa ${s.mushafPage}")
                }
            }
            "juzs" -> {
                MushafCatalog.JUZS.filter {
                    q.isEmpty() ||
                        it.juz.toString().contains(q) ||
                        it.surahName.lowercase(Locale("tr", "TR")).contains(q) ||
                        it.mushafPage.toString().contains(q)
                }.forEach { j ->
                    currentListTargets.add(j)
                    displayRows.add("${j.juz}. Cüz\nBaşlangıç: ${j.surahName} Suresi • Mushaf Sayfa ${j.mushafPage}")
                }
            }
            "bookmarks" -> {
                bookmarks.filter {
                    q.isEmpty() ||
                        it.note.lowercase(Locale("tr", "TR")).contains(q) ||
                        it.surahTitle.lowercase(Locale("tr", "TR")).contains(q)
                }.forEach { b ->
                    currentListTargets.add(b)
                    displayRows.add("🔖 ${b.note}\n${b.surahTitle} • Sayfa ${b.mushafPage} (${b.createdAt}) [Silmek için basılı tutun]")
                }
            }
        }

        val listAdapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            displayRows
        ) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(Color.parseColor("#ECFDF5"))
                v.textSize = 13f
                v.setPadding(24, 20, 24, 20)
                return v
            }
        }
        drawerListView.adapter = listAdapter
    }

    private fun showAddBookmarkDialog() {
        val meta = MushafCatalog.getPageMeta(currentPdfPage)
        val input = EditText(this).apply {
            hint = "Notunuz (Örn: Günlük Hatim, Sabah Okuması)"
            setText("Kaldığım Yer (Sayfa ${meta.mushafPage})")
            setSelectAllOnFocus(true)
        }

        AlertDialog.Builder(this)
            .setTitle("🔖 Yer İmi Ekle")
            .setMessage("${meta.surahTitle} • ${meta.mushafPageLabel} (${meta.juzLabel})")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val noteText = input.text.toString().trim().ifEmpty {
                    "Kaldığım Yer (Sayfa ${meta.mushafPage})"
                }
                val dateStr = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date())
                bookmarks.add(
                    0,
                    BookmarkItem(
                        System.currentTimeMillis().toString(),
                        currentPdfPage,
                        meta.mushafPage,
                        noteText,
                        meta.surahTitle,
                        dateStr
                    )
                )
                saveBookmarksToPrefs()
                updateTopAndBottomBar(currentPdfPage)
                Toast.makeText(this, "Yer imi kaydedildi: $noteText", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun showGoToPageDialog() {
        val input = EditText(this).apply {
            hint = "Mushaf Sayfa No (1 - 604)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(this)
            .setTitle("Mushaf Sayfasına Git")
            .setMessage("Gitmek istediğiniz Mushaf sayfa numarasını (1 - 604) girin:")
            .setView(input)
            .setPositiveButton("Git") { _, _ ->
                val pageNo = input.text.toString().toIntOrNull()
                if (pageNo != null && pageNo in 0..604) {
                    val targetPdf = MushafCatalog.mushafPageToPdfPage(pageNo)
                    scrollToPdfPage(targetPdf)
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun loadPreferences() {
        currentPdfPage = prefs.getInt("last_pdf_page", 2)
        isMenuVisible = prefs.getBoolean("menu_visible", false)
        if (isMenuVisible) {
            topAppBar.visibility = View.VISIBLE
            bottomControlBar.visibility = View.VISIBLE
            horizontalLockButton.visibility = View.VISIBLE
        } else {
            topAppBar.visibility = View.GONE
            bottomControlBar.visibility = View.GONE
            horizontalLockButton.visibility = View.GONE
        }
        val hLocked = prefs.getBoolean("horizontal_pan_locked", false)
        pdfRecyclerView.isHorizontalPanLocked = hLocked

        showPageHeaders = prefs.getBoolean("show_page_headers", false)
        seamlessReading = prefs.getBoolean("seamless_reading", true)
        fullscreenPure = prefs.getBoolean("fullscreen_pure", true)
        isNightMode = prefs.getBoolean("night_mode", false)

        switchPageHeaders.isChecked = showPageHeaders
        switchSeamlessReading.isChecked = seamlessReading
        switchFullscreenPure.isChecked = fullscreenPure
        switchNightModeSetting.isChecked = isNightMode
        nightModeBtn.text = if (isNightMode) "🌙 Gece" else "📜 Orijinal"

        val bmJson = prefs.getString("bookmarks_json", null)
        bookmarks.clear()
        if (!bmJson.isNullOrEmpty()) {
            try {
                val arr = JSONArray(bmJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    bookmarks.add(
                        BookmarkItem(
                            obj.optString("id"),
                            obj.optInt("pdfPage", 2),
                            obj.optInt("mushafPage", 1),
                            obj.optString("note", "Kaldığım Yer"),
                            obj.optString("surahTitle", "1. Fâtiha Suresi"),
                            obj.optString("createdAt", "")
                        )
                    )
                }
            } catch (_: Exception) {}
        } else {
            bookmarks.add(BookmarkItem("default_1", 2, 1, "Hatim Başlangıcı", "1. Fâtiha Suresi", "Hazır"))
            bookmarks.add(BookmarkItem("default_yasin", 441, 439, "Yâsîn-i Şerif", "36. Yâsîn Suresi", "Hazır"))
            bookmarks.add(BookmarkItem("default_mulk", 563, 561, "Mülk (Tebâreke) Suresi", "67. Mülk Suresi", "Hazır"))
        }
    }

    private fun saveLastReadPage(pdfPage: Int) {
        prefs.edit().putInt("last_pdf_page", pdfPage).apply()
    }

    private fun saveBookmarksToPrefs() {
        val arr = JSONArray()
        bookmarks.forEach { b ->
            val obj = JSONObject()
            obj.put("id", b.id)
            obj.put("pdfPage", b.pdfPage)
            obj.put("mushafPage", b.mushafPage)
            obj.put("note", b.note)
            obj.put("surahTitle", b.surahTitle)
            obj.put("createdAt", b.createdAt)
            arr.put(obj)
        }
        prefs.edit().putString("bookmarks_json", arr.toString()).apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        synchronized(renderLock) {
            pdfAdapter?.shutdown()
            try {
                pdfRenderer?.close()
                parcelFileDescriptor?.close()
            } catch (_: Exception) {}
        }
    }
}

class UltraHdPdfPageAdapter(
    private val pdfRenderer: PdfRenderer,
    private val renderMutex: Any
) : RecyclerView.Adapter<UltraHdPdfPageAdapter.PageViewHolder>() {

    var isNightMode: Boolean = false
    var showPageHeaders: Boolean = false
    var seamlessReading: Boolean = true
    var isFullscreen: Boolean = true
    var fullscreenPure: Boolean = true

    @Volatile
    private var currentViewportWidth: Int = 0

    private var hostRecyclerView: RecyclerView? = null

    // Mushaf gerçek sayfa oranı (height / width)
    private val defaultAspectRatio: Float = synchronized(renderMutex) {
        try {
            if (pdfRenderer.pageCount > 0) {
                val sampleIdx = if (pdfRenderer.pageCount > 2) 2 else 0
                val p = pdfRenderer.openPage(sampleIdx)
                val r = p.height.coerceAtLeast(1).toFloat() / p.width.coerceAtLeast(1).toFloat()
                p.close()
                r
            } else {
                780f / 539f
            }
        } catch (_: Exception) {
            780f / 539f
        }
    }

    private val pageRatios = FloatArray(pdfRenderer.pageCount.coerceAtLeast(1)) { defaultAspectRatio }

    private val executor = Executors.newFixedThreadPool(2)

    // Geniş RAM önbelleği (KB cinsinden, largeHeap ile ~192-256 MB)
    private val bitmapCache: LruCache<Int, Bitmap> = run {
        val maxMemKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        val cacheSizeKb = (maxMemKb / 2).coerceAtLeast(128 * 1024)
        object : LruCache<Int, Bitmap>(cacheSizeKb) {
            override fun sizeOf(key: Int, value: Bitmap): Int {
                return (value.byteCount / 1024).coerceAtLeast(1)
            }
        }
    }

    private val nightColorFilter = ColorMatrixColorFilter(
        ColorMatrix(
            floatArrayOf(
                -0.88f, 0f, 0f, 0f, 245f,
                0f, -0.88f, 0f, 0f, 240f,
                0f, 0f, -0.88f, 0f, 225f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    override fun getItemCount(): Int = pdfRenderer.pageCount

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        hostRecyclerView = recyclerView
        if (recyclerView.width > 0) {
            currentViewportWidth = recyclerView.width
        }
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        if (hostRecyclerView === recyclerView) {
            hostRecyclerView = null
        }
    }

    fun getExpectedPageHeight(position: Int, viewportWidth: Int): Int {
        val ratio = if (position in pageRatios.indices) pageRatios[position] else defaultAspectRatio
        return (viewportWidth * ratio).roundToInt()
    }

    private fun resolveViewportWidth(itemView: View): Int {
        val dm = itemView.resources.displayMetrics
        val dmW = dm.widthPixels
        val dmH = dm.heightPixels
        val rv = hostRecyclerView ?: (itemView.parent as? RecyclerView)
        val rvW = rv?.width ?: 0
        val rvH = rv?.height ?: 0

        if (rvW > 0 && rvH > 0 && dmW > 0 && dmH > 0) {
            val rvIsLandscape = rvW > rvH
            val dmIsLandscape = dmW > dmH
            if (rvIsLandscape == dmIsLandscape) {
                currentViewportWidth = rvW
                return rvW
            }
        }
        if (dmW > 0) {
            currentViewportWidth = dmW
            return dmW
        }
        if (rvW > 0) {
            currentViewportWidth = rvW
            return rvW
        }
        return currentViewportWidth.coerceAtLeast(1080)
    }

    fun syncHolderDimensions(holder: PageViewHolder, viewportWidth: Int = 0) {
        val effectiveWidth = viewportWidth.takeIf { it > 0 } ?: resolveViewportWidth(holder.itemView)
        val pos = holder.adapterPosition.takeIf { it != RecyclerView.NO_POSITION } ?: holder.boundPosition
        val ratio = if (pos in pageRatios.indices) pageRatios[pos] else defaultAspectRatio
        val exactHeight = (effectiveWidth * ratio).roundToInt()
        applyLockedHeight(holder, effectiveWidth, exactHeight)
    }

    fun updateViewportWidth(newWidth: Int, recyclerView: RecyclerView) {
        if (newWidth <= 0) return
        val widthChanged = (currentViewportWidth != newWidth)
        currentViewportWidth = newWidth

        for (i in 0 until recyclerView.childCount) {
            val child = recyclerView.getChildAt(i) ?: continue
            val vh = recyclerView.getChildViewHolder(child) as? PageViewHolder ?: continue
            syncHolderDimensions(vh, newWidth)
            child.requestLayout()
        }

        if (!recyclerView.isComputingLayout) {
            // Ekran dışı önbellekteki (mCachedViews) eski dikey/yatay boyutlu sayfaları temizle
            recyclerView.setItemViewCacheSize(0)
            recyclerView.setItemViewCacheSize(8)
            if (widthChanged) {
                notifyItemRangeChanged(0, itemCount, "VIEWPORT_RESIZE")
            }
            recyclerView.requestLayout()
        } else {
            recyclerView.post {
                if (!recyclerView.isComputingLayout) {
                    recyclerView.setItemViewCacheSize(0)
                    recyclerView.setItemViewCacheSize(8)
                    notifyItemRangeChanged(0, itemCount, "VIEWPORT_RESIZE")
                    recyclerView.requestLayout()
                }
            }
        }
    }

    private fun applyLockedHeight(holder: PageViewHolder, exactWidth: Int, exactHeight: Int) {
        val rootLp = holder.rootLayout.layoutParams
        if (rootLp != null && rootLp.width != ViewGroup.LayoutParams.MATCH_PARENT) {
            rootLp.width = ViewGroup.LayoutParams.MATCH_PARENT
            holder.rootLayout.layoutParams = rootLp
        }

        val container = holder.pageImage.parent as? View
        if (container != null) {
            val cLp = container.layoutParams
            if (cLp != null && (cLp.width != ViewGroup.LayoutParams.MATCH_PARENT || cLp.height != exactHeight)) {
                cLp.width = ViewGroup.LayoutParams.MATCH_PARENT
                cLp.height = exactHeight
                container.layoutParams = cLp
            }
            container.minimumHeight = exactHeight
        }

        val imgLp = holder.pageImage.layoutParams
        if (imgLp != null && (imgLp.width != ViewGroup.LayoutParams.MATCH_PARENT || imgLp.height != exactHeight)) {
            imgLp.width = ViewGroup.LayoutParams.MATCH_PARENT
            imgLp.height = exactHeight
            holder.pageImage.layoutParams = imgLp
        }
        holder.pageImage.minimumHeight = exactHeight
        holder.pageImage.adjustViewBounds = true
        holder.pageImage.scaleType = ImageView.ScaleType.FIT_CENTER
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        if (parent.width > 0) {
            currentViewportWidth = parent.width
        }
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pdf_page, parent, false)
        return PageViewHolder(view)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) {
            holder.boundPosition = position
            syncHolderDimensions(holder, currentViewportWidth)
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        val pdfPageNumber = position + 1
        val meta = MushafCatalog.getPageMeta(pdfPageNumber)

        val effectiveHideHeaders = !showPageHeaders || (isFullscreen && fullscreenPure)
        if (effectiveHideHeaders) {
            holder.headerBar.visibility = View.GONE
        } else {
            holder.headerBar.visibility = View.VISIBLE
            holder.surahTitle.text = meta.surahTitle
            holder.pageBadge.text = meta.mushafPageLabel
            holder.juzTitle.text = meta.juzLabel
        }

        val pageBg = if (isNightMode) Color.parseColor("#141816") else Color.parseColor("#FFF1D1")
        holder.rootLayout.setPadding(0, 0, 0, 0)
        holder.rootLayout.setBackgroundColor(pageBg)
        (holder.rootLayout.layoutParams as? RecyclerView.LayoutParams)?.let { lp ->
            if (lp.topMargin != 0 || lp.bottomMargin != 0 || lp.leftMargin != 0 || lp.rightMargin != 0) {
                lp.setMargins(0, 0, 0, 0)
                holder.rootLayout.layoutParams = lp
            }
        }
        holder.dividerLine.visibility = View.GONE

        holder.boundPosition = position

        // Gerçek ekran genişliğine göre sayfa yüksekliğini orantılı (bozulmasız) sabitle
        val viewWidth = resolveViewportWidth(holder.itemView)
        val ratio = if (position in pageRatios.indices) pageRatios[position] else defaultAspectRatio
        val exactHeight = (viewWidth * ratio).roundToInt()
        applyLockedHeight(holder, viewWidth, exactHeight)

        holder.pageImage.colorFilter = if (isNightMode) nightColorFilter else null
        holder.pageImage.setBackgroundColor(pageBg)
        (holder.pageImage.parent as? View)?.let { parentFrame ->
            parentFrame.setPadding(0, 0, 0, 0)
            parentFrame.setBackgroundColor(pageBg)
        }

        val dm = holder.itemView.resources.displayMetrics
        val maxScreenDim = maxOf(dm.widthPixels, dm.heightPixels).coerceAtLeast(1080)
        val targetRenderWidth = (maxScreenDim * 1.15f).toInt().coerceIn(2200, 2760)

        val cached = bitmapCache.get(position)
        if (cached != null && !cached.isRecycled) {
            holder.pageImage.setImageBitmap(cached)
            holder.loadingBar.visibility = View.GONE
            prefetchNeighbors(position, targetRenderWidth)
        } else {
            holder.pageImage.setImageDrawable(null)
            holder.loadingBar.visibility = View.VISIBLE
            executor.execute {
                val bmp = renderPage(position, targetRenderWidth)
                if (bmp != null) {
                    bitmapCache.put(position, bmp)
                    holder.pageImage.post {
                        if (holder.boundPosition == position) {
                            val currentW = resolveViewportWidth(holder.itemView)
                            val updatedH = (currentW * pageRatios[position]).roundToInt()
                            applyLockedHeight(holder, currentW, updatedH)
                            holder.pageImage.setImageBitmap(bmp)
                            holder.loadingBar.visibility = View.GONE
                        }
                    }
                    prefetchNeighbors(position, targetRenderWidth)
                }
            }
        }
    }

    private fun prefetchNeighbors(centerPos: Int, targetRenderWidth: Int) {
        val neighbors = intArrayOf(centerPos - 1, centerPos + 1)
        for (pos in neighbors) {
            if (pos in 0 until pdfRenderer.pageCount) {
                val existing = bitmapCache.get(pos)
                if (existing == null || existing.isRecycled) {
                    executor.execute {
                        val current = bitmapCache.get(pos)
                        if (current == null || current.isRecycled) {
                            val bmp = renderPage(pos, targetRenderWidth)
                            if (bmp != null) {
                                bitmapCache.put(pos, bmp)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun renderPage(position: Int, targetWidthPx: Int): Bitmap? {
        synchronized(renderMutex) {
            return try {
                if (position < 0 || position >= pdfRenderer.pageCount) return null
                val page = pdfRenderer.openPage(position)
                val pWidth = page.width.coerceAtLeast(1)
                val pHeight = page.height.coerceAtLeast(1)
                pageRatios[position] = pHeight.toFloat() / pWidth.toFloat()

                val renderWidth = targetWidthPx.coerceIn(1800, 2760)
                val renderHeight = (renderWidth.toFloat() * pHeight / pWidth).roundToInt()

                val bitmap = try {
                    Bitmap.createBitmap(renderWidth, renderHeight, Bitmap.Config.ARGB_8888)
                } catch (oom: OutOfMemoryError) {
                    bitmapCache.trimToSize(bitmapCache.maxSize() / 2)
                    val fallbackW = 1800
                    val fallbackH = (fallbackW.toFloat() * pHeight / pWidth).roundToInt()
                    Bitmap.createBitmap(fallbackW, fallbackH, Bitmap.Config.ARGB_8888)
                }

                bitmap.eraseColor(Color.parseColor("#FFF1D1"))
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                bitmap
            } catch (e: Exception) {
                null
            }
        }
    }

    fun shutdown() {
        executor.shutdownNow()
        bitmapCache.evictAll()
    }

    class PageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rootLayout: LinearLayout = view.findViewById(R.id.pageRootLayout)
        val headerBar: LinearLayout = view.findViewById(R.id.pageHeaderBar)
        val surahTitle: TextView = view.findViewById(R.id.pageHeaderSurah)
        val pageBadge: TextView = view.findViewById(R.id.pageHeaderNumber)
        val juzTitle: TextView = view.findViewById(R.id.pageHeaderJuz)
        val pageImage: ImageView = view.findViewById(R.id.pageImageView)
        val loadingBar: ProgressBar = view.findViewById(R.id.pageLoadingProgress)
        val dividerLine: View = view.findViewById(R.id.pageSeamlessDivider)
        var boundPosition: Int = -1
    }
}
