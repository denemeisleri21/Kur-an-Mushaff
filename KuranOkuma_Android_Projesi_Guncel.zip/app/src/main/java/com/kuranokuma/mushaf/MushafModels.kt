package com.kuranokuma.mushaf

data class SurahItem(
    val no: Int,
    val name: String,
    val arabic: String,
    val ayet: Int,
    val type: String,
    val mushafPage: Int,
    val pdfPage: Int,
    val juz: Int
) {
    val ayetCount: Int get() = ayet
}

data class JuzItem(
    val juzNo: Int,
    val title: String,
    val mushafPage: Int,
    val pdfPage: Int,
    val firstSurah: String
) {
    val juz: Int get() = juzNo
    val name: String get() = title
    val surahName: String get() = firstSurah
}

data class BookmarkItem(
    val id: String,
    val pdfPage: Int,
    val mushafPage: Int,
    val note: String,
    val surahName: String,
    val createdAt: String
) {
    val surahTitle: String get() = surahName
}

data class PageMeta(
    val pdfPage: Int,
    val mushafPage: Int,
    val mushafPageLabel: String,
    val surahTitle: String,
    val arabicTitle: String,
    val juzLabel: String
)

object MushafCatalog {
    const val TOTAL_PDF_PAGES = 616

    val SURAHS: List<SurahItem> = listOf(
        SurahItem(1, "Fâtiha", "الفاتحة", 7, "Mekkî", 1, 2, 1),
        SurahItem(2, "Bakara", "البقرة", 286, "Medenî", 1, 3, 1),
        SurahItem(3, "Âl-i İmrân", "آل عمران", 200, "Medenî", 49, 51, 3),
        SurahItem(4, "Nisâ", "النساء", 176, "Medenî", 76, 78, 4),
        SurahItem(5, "Mâide", "المائدة", 120, "Medenî", 105, 107, 6),
        SurahItem(6, "En'âm", "الأنعام", 165, "Mekkî", 127, 129, 7),
        SurahItem(7, "A'râf", "الأعراف", 206, "Mekkî", 150, 152, 8),
        SurahItem(8, "Enfâl", "الأنفال", 75, "Medenî", 176, 178, 9),
        SurahItem(9, "Tevbe", "التوبة", 129, "Medenî", 186, 188, 10),
        SurahItem(10, "Yûnus", "يونس", 109, "Mekkî", 207, 209, 11),
        SurahItem(11, "Hûd", "هود", 123, "Mekkî", 220, 222, 11),
        SurahItem(12, "Yûsuf", "يوسف", 111, "Mekkî", 234, 236, 12),
        SurahItem(13, "Ra'd", "الرعد", 43, "Medenî", 248, 250, 13),
        SurahItem(14, "İbrâhîm", "إبراهيم", 52, "Mekkî", 254, 256, 13),
        SurahItem(15, "Hicr", "الحجر", 99, "Mekkî", 261, 263, 14),
        SurahItem(16, "Nahl", "النحل", 128, "Mekkî", 266, 268, 14),
        SurahItem(17, "İsrâ", "الإسراء", 111, "Mekkî", 281, 283, 15),
        SurahItem(18, "Kehf", "الكهف", 110, "Mekkî", 292, 294, 15),
        SurahItem(19, "Meryem", "مريم", 98, "Mekkî", 304, 306, 16),
        SurahItem(20, "Tâhâ", "طه", 135, "Mekkî", 311, 313, 16),
        SurahItem(21, "Enbiyâ", "الأنبياء", 112, "Mekkî", 321, 323, 17),
        SurahItem(22, "Hac", "الحج", 78, "Medenî", 331, 333, 17),
        SurahItem(23, "Mü'minûn", "المؤمنون", 118, "Mekkî", 341, 343, 18),
        SurahItem(24, "Nûr", "النور", 64, "Medenî", 349, 351, 18),
        SurahItem(25, "Furkan", "الفرقان", 77, "Mekkî", 357, 359, 18),
        SurahItem(26, "Şuarâ", "الشعراء", 227, "Mekkî", 366, 368, 19),
        SurahItem(27, "Neml", "النمل", 93, "Mekkî", 376, 378, 19),
        SurahItem(28, "Kasas", "القصص", 88, "Mekkî", 384, 386, 20),
        SurahItem(29, "Ankebût", "العنكبوت", 69, "Mekkî", 395, 397, 20),
        SurahItem(30, "Rûm", "الروم", 60, "Mekkî", 403, 405, 21),
        SurahItem(31, "Lokmân", "لقمان", 34, "Mekkî", 410, 412, 21),
        SurahItem(32, "Secde", "السجدة", 30, "Mekkî", 414, 416, 21),
        SurahItem(33, "Ahzâb", "الأحزاب", 73, "Medenî", 417, 419, 21),
        SurahItem(34, "Sebe'", "سبأ", 54, "Mekkî", 427, 429, 22),
        SurahItem(35, "Fâtır", "فاطر", 45, "Mekkî", 433, 435, 22),
        SurahItem(36, "Yâsîn", "يس", 83, "Mekkî", 439, 441, 22),
        SurahItem(37, "Sâffât", "الصافات", 182, "Mekkî", 445, 447, 23),
        SurahItem(38, "Sâd", "ص", 88, "Mekkî", 452, 454, 23),
        SurahItem(39, "Zümer", "الزمر", 75, "Mekkî", 457, 459, 23),
        SurahItem(40, "Mü'min", "غافر", 85, "Mekkî", 466, 468, 24),
        SurahItem(41, "Fussilet", "فصلت", 54, "Mekkî", 476, 478, 24),
        SurahItem(42, "Şûrâ", "الشورى", 53, "Mekkî", 482, 484, 25),
        SurahItem(43, "Zuhruf", "الزخرف", 89, "Mekkî", 488, 490, 25),
        SurahItem(44, "Duhân", "الدخان", 59, "Mekkî", 495, 497, 25),
        SurahItem(45, "Câsiye", "الجاثية", 37, "Mekkî", 496, 498, 25),
        SurahItem(46, "Ahkâf", "الأحقاف", 35, "Mekkî", 501, 503, 26),
        SurahItem(47, "Muhammed", "محمد", 38, "Medenî", 506, 508, 26),
        SurahItem(48, "Fetih", "الفتح", 29, "Medenî", 510, 512, 26),
        SurahItem(49, "Hucurât", "الحجرات", 18, "Medenî", 514, 516, 26),
        SurahItem(50, "Kâf", "ق", 45, "Mekkî", 517, 519, 26),
        SurahItem(51, "Zâriyât", "الذاريات", 60, "Mekkî", 519, 521, 26),
        SurahItem(52, "Tûr", "الطور", 49, "Mekkî", 522, 524, 27),
        SurahItem(53, "Necm", "النجم", 62, "Mekkî", 525, 527, 27),
        SurahItem(54, "Kamer", "القمر", 55, "Mekkî", 527, 529, 27),
        SurahItem(55, "Rahmân", "الرحمن", 78, "Medenî", 530, 532, 27),
        SurahItem(56, "Vâkıa", "الواقعة", 96, "Mekkî", 533, 535, 27),
        SurahItem(57, "Hadîd", "الحديد", 29, "Medenî", 536, 538, 27),
        SurahItem(58, "Mücâdele", "المجادلة", 22, "Medenî", 541, 543, 28),
        SurahItem(59, "Haşr", "الحشر", 24, "Medenî", 544, 546, 28),
        SurahItem(60, "Mümtehine", "الممتحنة", 13, "Medenî", 546, 548, 28),
        SurahItem(61, "Saf", "الصف", 14, "Medenî", 550, 552, 28),
        SurahItem(62, "Cuma", "الجمعة", 11, "Medenî", 552, 554, 28),
        SurahItem(63, "Münâfikûn", "المنافقون", 11, "Medenî", 553, 555, 28),
        SurahItem(64, "Tegâbün", "التغابن", 18, "Medenî", 555, 557, 28),
        SurahItem(65, "Talâk", "الطلاق", 12, "Medenî", 557, 559, 28),
        SurahItem(66, "Tahrîm", "التحريم", 12, "Medenî", 559, 561, 28),
        SurahItem(67, "Mülk", "الملك", 30, "Mekkî", 561, 563, 29),
        SurahItem(68, "Kalem", "القلم", 52, "Mekkî", 563, 565, 29),
        SurahItem(69, "Hâkka", "الحاقة", 52, "Mekkî", 565, 567, 29),
        SurahItem(70, "Meâric", "المعارج", 44, "Mekkî", 567, 569, 29),
        SurahItem(71, "Nûh", "نوح", 28, "Mekkî", 569, 571, 29),
        SurahItem(72, "Cin", "الجن", 28, "Mekkî", 571, 573, 29),
        SurahItem(73, "Müzzemmil", "المزمل", 20, "Mekkî", 573, 575, 29),
        SurahItem(74, "Müddessir", "المدثر", 56, "Mekkî", 574, 576, 29),
        SurahItem(75, "Kıyâme", "القيامة", 40, "Mekkî", 576, 578, 29),
        SurahItem(76, "İnsân", "الإنسان", 31, "Medenî", 577, 579, 29),
        SurahItem(77, "Mürselât", "المرسلات", 50, "Mekkî", 579, 581, 29),
        SurahItem(78, "Nebe'", "النبأ", 40, "Mekkî", 581, 583, 30),
        SurahItem(79, "Nâziât", "النازعات", 46, "Mekkî", 582, 584, 30),
        SurahItem(80, "Abese", "عبس", 42, "Mekkî", 584, 586, 30),
        SurahItem(81, "Tekvîr", "التكوير", 29, "Mekkî", 585, 587, 30),
        SurahItem(82, "İnfitâr", "الانفطار", 19, "Mekkî", 586, 588, 30),
        SurahItem(83, "Mutaffifîn", "المطففين", 36, "Mekkî", 587, 589, 30),
        SurahItem(84, "İnşikâk", "الانشقاق", 25, "Mekkî", 588, 590, 30),
        SurahItem(85, "Bürûc", "البروج", 22, "Mekkî", 589, 591, 30),
        SurahItem(86, "Târık", "الطارق", 17, "Mekkî", 590, 592, 30),
        SurahItem(87, "A'lâ", "الأعلى", 19, "Mekkî", 591, 593, 30),
        SurahItem(88, "Gâşiye", "الغاشية", 26, "Mekkî", 591, 593, 30),
        SurahItem(89, "Fecr", "الفجر", 30, "Mekkî", 592, 594, 30),
        SurahItem(90, "Beled", "البلد", 20, "Mekkî", 593, 595, 30),
        SurahItem(91, "Şems", "الشمس", 15, "Mekkî", 594, 596, 30),
        SurahItem(92, "Leyl", "الليل", 21, "Mekkî", 595, 597, 30),
        SurahItem(93, "Duhâ", "الضحى", 11, "Mekkî", 595, 597, 30),
        SurahItem(94, "İnşirâh", "الشرح", 8, "Mekkî", 596, 598, 30),
        SurahItem(95, "Tîn", "التين", 8, "Mekkî", 596, 598, 30),
        SurahItem(96, "Alak", "العلق", 19, "Mekkî", 597, 599, 30),
        SurahItem(97, "Kadir", "القدر", 5, "Mekkî", 598, 600, 30),
        SurahItem(98, "Beyyine", "البينة", 8, "Medenî", 598, 600, 30),
        SurahItem(99, "Zilzâl", "الزلزلة", 8, "Medenî", 599, 601, 30),
        SurahItem(100, "Âdiyât", "العاديات", 11, "Mekkî", 599, 601, 30),
        SurahItem(101, "Kâria", "القارعة", 11, "Mekkî", 600, 602, 30),
        SurahItem(102, "Tekâsür", "التكاثر", 8, "Mekkî", 600, 602, 30),
        SurahItem(103, "Asr", "العصر", 3, "Mekkî", 601, 603, 30),
        SurahItem(104, "Hümeze", "الهمزة", 9, "Mekkî", 601, 603, 30),
        SurahItem(105, "Fîl", "الفيل", 5, "Mekkî", 601, 603, 30),
        SurahItem(106, "Kureyş", "قريش", 4, "Mekkî", 602, 604, 30),
        SurahItem(107, "Mâûn", "الماعون", 7, "Mekkî", 602, 604, 30),
        SurahItem(108, "Kevser", "الكوثر", 3, "Mekkî", 602, 604, 30),
        SurahItem(109, "Kâfirûn", "الكافرون", 6, "Mekkî", 603, 605, 30),
        SurahItem(110, "Nasr", "النصر", 3, "Medenî", 603, 605, 30),
        SurahItem(111, "Tebbet", "المسد", 5, "Mekkî", 603, 605, 30),
        SurahItem(112, "İhlâs", "الإخلاص", 4, "Mekkî", 604, 606, 30),
        SurahItem(113, "Felak", "الفلق", 5, "Mekkî", 604, 606, 30),
        SurahItem(114, "Nâs", "الناس", 6, "Mekkî", 604, 606, 30)
    )

    val JUZS: List<JuzItem> = listOf(
        JuzItem(1, "1. Cüz", 1, 2, "Bakara"),
        JuzItem(2, "2. Cüz", 21, 23, "Bakara"),
        JuzItem(3, "3. Cüz", 41, 43, "Bakara"),
        JuzItem(4, "4. Cüz", 61, 63, "Âl-i İmrân"),
        JuzItem(5, "5. Cüz", 81, 83, "Nisâ"),
        JuzItem(6, "6. Cüz", 101, 103, "Nisâ"),
        JuzItem(7, "7. Cüz", 121, 123, "Mâide"),
        JuzItem(8, "8. Cüz", 141, 143, "En'âm"),
        JuzItem(9, "9. Cüz", 161, 163, "A'râf"),
        JuzItem(10, "10. Cüz", 181, 183, "Enfâl"),
        JuzItem(11, "11. Cüz", 201, 203, "Tevbe"),
        JuzItem(12, "12. Cüz", 221, 223, "Hûd"),
        JuzItem(13, "13. Cüz", 241, 243, "Yûsuf"),
        JuzItem(14, "14. Cüz", 261, 263, "Hicr"),
        JuzItem(15, "15. Cüz", 281, 283, "İsrâ"),
        JuzItem(16, "16. Cüz", 301, 303, "Kehf"),
        JuzItem(17, "17. Cüz", 321, 323, "Enbiyâ"),
        JuzItem(18, "18. Cüz", 341, 343, "Mü'minûn"),
        JuzItem(19, "19. Cüz", 361, 363, "Furkan"),
        JuzItem(20, "20. Cüz", 381, 383, "Neml"),
        JuzItem(21, "21. Cüz", 401, 403, "Ankebût"),
        JuzItem(22, "22. Cüz", 421, 423, "Ahzâb"),
        JuzItem(23, "23. Cüz", 441, 443, "Yâsîn"),
        JuzItem(24, "24. Cüz", 461, 463, "Zümer"),
        JuzItem(25, "25. Cüz", 481, 483, "Fussilet"),
        JuzItem(26, "26. Cüz", 501, 503, "Ahkâf"),
        JuzItem(27, "27. Cüz", 521, 523, "Zâriyât"),
        JuzItem(28, "28. Cüz", 541, 543, "Mücâdele"),
        JuzItem(29, "29. Cüz", 561, 563, "Mülk"),
        JuzItem(30, "30. Cüz", 581, 583, "Nebe'")
    )

    fun pdfPageToMushafPage(pdfPage: Int): Int {
        if (pdfPage <= 1) return 0
        if (pdfPage == 2 || pdfPage == 3) return 1
        if (pdfPage in 4..606) return pdfPage - 2
        return 604
    }

    fun mushafPageToPdfPage(mushafPage: Int): Int {
        if (mushafPage <= 0) return 1
        if (mushafPage == 1) return 2
        if (mushafPage >= 604) return 606
        return mushafPage + 2
    }

    fun getPageMeta(pdfPage: Int): PageMeta {
        if (pdfPage <= 1) {
            return PageMeta(1, 0, "Kapak", "Kur'an-ı Kerim", "القرآن الكريم", "Diyanet Mushafı")
        }
        if (pdfPage == 2) {
            return PageMeta(2, 1, "Mushaf Sayfa 1 (Fâtiha)", "1. Fâtiha Suresi", "الفاتحة", "1. Cüz")
        }
        if (pdfPage == 3) {
            return PageMeta(3, 1, "Mushaf Sayfa 1 (Bakara)", "2. Bakara Suresi", "البقرة", "1. Cüz")
        }
        if (pdfPage in 607..610) {
            return PageMeta(pdfPage, 604, "Hatim Duası (${pdfPage - 606}/4)", "Hatim Duası", "دعاء الختم", "30. Cüz Sonu")
        }
        if (pdfPage in 611..612) {
            return PageMeta(pdfPage, 604, "Vakıf İşaretleri", "Vakıf Alâmetleri", "علامات الوقف", "Rehber")
        }
        if (pdfPage in 613..615) {
            return PageMeta(pdfPage, 604, "Sure ve Cüz Fihristi", "Fihrist", "فهرس السور", "İndeks")
        }
        if (pdfPage >= 616) {
            return PageMeta(616, 604, "Mushaf Künyesi", "Künye", "القرآن الكريم", "Diyanet Yayınları")
        }

        val mushafPage = pdfPage - 2
        val juzNo = if (mushafPage <= 20) 1 else minOf(30, ((mushafPage - 1) / 20) + 1)
        var activeSurah = SURAHS[1]
        for (s in SURAHS) {
            if (s.mushafPage <= mushafPage) {
                activeSurah = s
            } else {
                break
            }
        }
        return PageMeta(
            pdfPage = pdfPage,
            mushafPage = mushafPage,
            mushafPageLabel = "Mushaf Sayfa $mushafPage",
            surahTitle = "${activeSurah.no}. ${activeSurah.name} Suresi",
            arabicTitle = activeSurah.arabic,
            juzLabel = "$juzNo. Cüz"
        )
    }
}
