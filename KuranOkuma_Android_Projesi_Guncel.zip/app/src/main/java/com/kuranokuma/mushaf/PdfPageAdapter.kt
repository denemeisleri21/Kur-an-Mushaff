package com.kuranokuma.mushaf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.pdf.PdfRenderer
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class PdfPageAdapter(
    private val pdfRenderer: PdfRenderer,
    private val renderMutex: Any
) : RecyclerView.Adapter<PdfPageAdapter.PageViewHolder>() {

    var isNightMode: Boolean = false
    var showPageHeaders: Boolean = false
    var seamlessReading: Boolean = true
    var isFullscreen: Boolean = true
    var fullscreenPure: Boolean = true

    @Volatile
    private var currentViewportWidth: Int = 0

    // Mushaf standart sayfa oranı (780 / 539 = 1.4471243f)
    private val defaultAspectRatio = 780f / 539f
    private val pageRatios = FloatArray(pdfRenderer.pageCount.coerceAtLeast(1)) { defaultAspectRatio }

    private val executor = Executors.newFixedThreadPool(2)

    // Geniş RAM önbelleği (KB cinsinden, largeHeap ile ~192-256 MB)
    private val bitmapCache: LruCache<Int, Bitmap> = run {
        val maxMemKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        val cacheSizeKb = (maxMemKb / 2).coerceAtLeast(128 * 1024)
        object : LruCache<Int, Bitmap>(cacheSizeKb) {
            override fun sizeOf(key: Int, value: Bitmap): Int {
                return (value.byteCount / 1024).coerceAtLeast(1)
            }
        }
    }

    private val nightColorFilter = ColorMatrixColorFilter(
        ColorMatrix(
            floatArrayOf(
                -0.88f, 0f, 0f, 0f, 245f,
                0f, -0.88f, 0f, 0f, 240f,
                0f, 0f, -0.88f, 0f, 225f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    override fun getItemCount(): Int = pdfRenderer.pageCount

    fun updateViewportWidth(newWidth: Int, recyclerView: RecyclerView) {
        if (newWidth <= 0) return
        currentViewportWidth = newWidth
        for (i in 0 until recyclerView.childCount) {
            val child = recyclerView.getChildAt(i) ?: continue
            val vh = recyclerView.getChildViewHolder(child) as? PageViewHolder ?: continue
            val pos = vh.adapterPosition.takeIf { it != RecyclerView.NO_POSITION } ?: vh.boundPosition
            if (pos in pageRatios.indices) {
                val exactHeight = (newWidth * pageRatios[pos]).toInt()
                applyLockedHeight(vh, exactHeight)
            }
        }
    }

    private fun applyLockedHeight(holder: PageViewHolder, exactHeight: Int) {
        val imgLp = holder.pageImage.layoutParams
        if (imgLp != null && imgLp.height != exactHeight) {
            imgLp.height = exactHeight
            holder.pageImage.layoutParams = imgLp
        }
        holder.pageImage.minimumHeight = exactHeight
        (holder.pageImage.parent as? View)?.minimumHeight = exactHeight
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        if (parent.width > 0) {
            currentViewportWidth = parent.width
        }
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pdf_page, parent, false)
        return PageViewHolder(view)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        val pdfPageNumber = position + 1
        val meta = MushafCatalog.getPageMeta(pdfPageNumber)

        val effectiveHideHeaders = !showPageHeaders || (isFullscreen && fullscreenPure)
        if (effectiveHideHeaders) {
            holder.headerBar.visibility = View.GONE
        } else {
            holder.headerBar.visibility = View.VISIBLE
            holder.surahTitle.text = meta.surahTitle
            holder.pageBadge.text = meta.mushafPageLabel
            holder.juzTitle.text = meta.juzLabel
        }

        val pageBg = if (isNightMode) Color.parseColor("#141816") else Color.parseColor("#FFF1D1")
        holder.rootLayout.setPadding(0, 0, 0, 0)
        holder.rootLayout.setBackgroundColor(pageBg)
        (holder.rootLayout.layoutParams as? RecyclerView.LayoutParams)?.let { lp ->
            if (lp.topMargin != 0 || lp.bottomMargin != 0 || lp.leftMargin != 0 || lp.rightMargin != 0) {
                lp.setMargins(0, 0, 0, 0)
                holder.rootLayout.layoutParams = lp
            }
        }
        holder.dividerLine.visibility = View.GONE

        // KRİTİK: Sayfa yüksekliğini bitmap yüklenmeden ÖNCE kesin olarak sabitle!
        // Böylece yatay ekranda yukarı doğru kaydırırken sayfa boyutu sonradan değişip takılma yapmaz.
        val dm = holder.itemView.resources.displayMetrics
        val viewWidth = currentViewportWidth.takeIf { it > 0 } ?: dm.widthPixels
        val ratio = if (position in pageRatios.indices) pageRatios[position] else defaultAspectRatio
        val exactHeight = (viewWidth * ratio).toInt()

        holder.pageImage.adjustViewBounds = false
        holder.pageImage.scaleType = ImageView.ScaleType.FIT_XY
        applyLockedHeight(holder, exactHeight)

        holder.pageImage.colorFilter = if (isNightMode) nightColorFilter else null
        holder.pageImage.setBackgroundColor(pageBg)
        (holder.pageImage.parent as? View)?.let { parentFrame ->
            parentFrame.setPadding(0, 0, 0, 0)
            parentFrame.setBackgroundColor(pageBg)
        }

        holder.boundPosition = position

        // Ultra-HD hedef genişlik (hem dikeyde hem yatayda cam gibi net 2.5K - 3K çözünürlük)
        val maxScreenDim = maxOf(dm.widthPixels, dm.heightPixels).coerceAtLeast(1080)
        val targetRenderWidth = (maxScreenDim * 1.15f).toInt().coerceIn(2200, 2760)

        val cached = bitmapCache.get(position)
        if (cached != null && !cached.isRecycled) {
            holder.pageImage.setImageBitmap(cached)
            holder.loadingBar.visibility = View.GONE
            prefetchNeighbors(position, targetRenderWidth)
        } else {
            holder.pageImage.setImageDrawable(null)
            holder.loadingBar.visibility = View.VISIBLE
            executor.execute {
                val bmp = renderPage(position, targetRenderWidth)
                if (bmp != null) {
                    bitmapCache.put(position, bmp)
                    holder.pageImage.post {
                        if (holder.boundPosition == position) {
                            val currentW = currentViewportWidth.takeIf { it > 0 } ?: dm.widthPixels
                            val updatedH = (currentW * pageRatios[position]).toInt()
                            applyLockedHeight(holder, updatedH)
                            holder.pageImage.setImageBitmap(bmp)
                            holder.loadingBar.visibility = View.GONE
                        }
                    }
                    prefetchNeighbors(position, targetRenderWidth)
                }
            }
        }
    }

    private fun prefetchNeighbors(centerPos: Int, targetRenderWidth: Int) {
        // Yukarı ve aşağı kaydırmanın anında hazır olması için önceki ve sonraki sayfayı arka planda hazırla
        val neighbors = intArrayOf(centerPos - 1, centerPos + 1)
        for (pos in neighbors) {
            if (pos in 0 until pdfRenderer.pageCount) {
                val existing = bitmapCache.get(pos)
                if (existing == null || existing.isRecycled) {
                    executor.execute {
                        val current = bitmapCache.get(pos)
                        if (current == null || current.isRecycled) {
                            val bmp = renderPage(pos, targetRenderWidth)
                            if (bmp != null) {
                                bitmapCache.put(pos, bmp)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun renderPage(position: Int, targetWidthPx: Int): Bitmap? {
        synchronized(renderMutex) {
            return try {
                if (position < 0 || position >= pdfRenderer.pageCount) return null
                val page = pdfRenderer.openPage(position)
                val pWidth = page.width.coerceAtLeast(1)
                val pHeight = page.height.coerceAtLeast(1)
                pageRatios[position] = pHeight.toFloat() / pWidth.toFloat()

                val renderWidth = targetWidthPx.coerceIn(1800, 2760)
                val renderHeight = (renderWidth.toFloat() * pHeight / pWidth).toInt()

                val bitmap = try {
                    Bitmap.createBitmap(renderWidth, renderHeight, Bitmap.Config.ARGB_8888)
                } catch (oom: OutOfMemoryError) {
                    bitmapCache.trimToSize(bitmapCache.maxSize() / 2)
                    val fallbackW = 1800
                    val fallbackH = (fallbackW.toFloat() * pHeight / pWidth).toInt()
                    Bitmap.createBitmap(fallbackW, fallbackH, Bitmap.Config.ARGB_8888)
                }

                bitmap.eraseColor(Color.parseColor("#FFF1D1"))
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                bitmap
            } catch (e: Exception) {
                null
            }
        }
    }

    fun shutdown() {
        executor.shutdownNow()
        bitmapCache.evictAll()
    }

    class PageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rootLayout: LinearLayout = view.findViewById(R.id.pageRootLayout)
        val headerBar: LinearLayout = view.findViewById(R.id.pageHeaderBar)
        val surahTitle: TextView = view.findViewById(R.id.pageHeaderSurah)
        val pageBadge: TextView = view.findViewById(R.id.pageHeaderNumber)
        val juzTitle: TextView = view.findViewById(R.id.pageHeaderJuz)
        val pageImage: ImageView = view.findViewById(R.id.pageImageView)
        val loadingBar: ProgressBar = view.findViewById(R.id.pageLoadingProgress)
        val dividerLine: View = view.findViewById(R.id.pageSeamlessDivider)
        var boundPosition: Int = -1
    }
}
