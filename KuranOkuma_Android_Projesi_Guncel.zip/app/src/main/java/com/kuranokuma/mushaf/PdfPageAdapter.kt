package com.kuranokuma.mushaf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.pdf.PdfRenderer
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class PdfPageAdapter(
    private val pdfRenderer: PdfRenderer,
    private val renderMutex: Any
) : RecyclerView.Adapter<PdfPageAdapter.PageViewHolder>() {

    var isNightMode: Boolean = false
    var showPageHeaders: Boolean = false
    var seamlessReading: Boolean = true
    var isFullscreen: Boolean = false
    var fullscreenPure: Boolean = true

    private val executor = Executors.newFixedThreadPool(2)
    private val bitmapCache = object : LruCache<Int, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    private val nightColorFilter = ColorMatrixColorFilter(
        ColorMatrix(
            floatArrayOf(
                -0.88f, 0f, 0f, 0f, 245f,
                0f, -0.88f, 0f, 0f, 240f,
                0f, 0f, -0.88f, 0f, 225f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    override fun getItemCount(): Int = pdfRenderer.pageCount

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pdf_page, parent, false)
        return PageViewHolder(view)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        val pdfPageNumber = position + 1
        val meta = MushafCatalog.getPageMeta(pdfPageNumber)

        val effectiveHideHeaders = !showPageHeaders || (isFullscreen && fullscreenPure)
        val effectiveSeamless = seamlessReading || (isFullscreen && fullscreenPure)

        if (effectiveHideHeaders) {
            holder.headerBar.visibility = View.GONE
        } else {
            holder.headerBar.visibility = View.VISIBLE
            holder.surahTitle.text = meta.surahTitle
            holder.pageBadge.text = meta.mushafPageLabel
            holder.juzTitle.text = meta.juzLabel
        }

        holder.rootLayout.setPadding(0, 0, 0, 0)
        val lp = holder.rootLayout.layoutParams as? RecyclerView.LayoutParams
        val density = holder.itemView.resources.displayMetrics.density
        if (lp != null) {
            if (effectiveSeamless) {
                lp.topMargin = 0
                lp.bottomMargin = 0
                lp.leftMargin = 0
                lp.rightMargin = 0
            } else {
                val marginV = 0
                val marginH = 0
                lp.topMargin = marginV
                lp.bottomMargin = marginV
                lp.leftMargin = marginH
                lp.rightMargin = marginH
            }
            holder.rootLayout.layoutParams = lp
        }

        if (effectiveSeamless) {
            holder.dividerLine.visibility = View.GONE
            holder.dividerLine.setBackgroundColor(
                if (isNightMode) Color.parseColor("#22D4AF37") else Color.parseColor("#28D4AF37")
            )
        } else {
            holder.dividerLine.visibility = View.GONE
        }

        holder.pageImage.colorFilter = if (isNightMode) nightColorFilter else null
        holder.pageImage.setBackgroundColor(
            if (isNightMode) Color.parseColor("#141816") else Color.parseColor("#FFF1D1")
        )

        holder.boundPosition = position
        val cached = bitmapCache.get(position)
        if (cached != null && !cached.isRecycled) {
            holder.pageImage.setImageBitmap(cached)
            holder.loadingBar.visibility = View.GONE
        } else {
            holder.pageImage.setImageDrawable(null)
            holder.loadingBar.visibility = View.VISIBLE
            val screenWidth = holder.itemView.resources.displayMetrics.widthPixels.coerceAtLeast(720)
            executor.execute {
                val bmp = renderPage(position, screenWidth)
                if (bmp != null) {
                    bitmapCache.put(position, bmp)
                    holder.pageImage.post {
                        if (holder.boundPosition == position) {
                            holder.pageImage.setImageBitmap(bmp)
                            holder.loadingBar.visibility = View.GONE
                        }
                    }
                }
            }
        }
    }

    private fun renderPage(position: Int, targetWidthPx: Int): Bitmap? {
        synchronized(renderMutex) {
            return try {
                if (position < 0 || position >= pdfRenderer.pageCount) return null
                val page = pdfRenderer.openPage(position)
                val renderWidth = (targetWidthPx * 1.45f).toInt().coerceIn(800, 1920)
                val renderHeight = (renderWidth.toFloat() * page.height / page.width.coerceAtLeast(1)).toInt()
                val bitmap = Bitmap.createBitmap(renderWidth, renderHeight, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(Color.parseColor("#FFF1D1"))
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                bitmap
            } catch (e: Exception) {
                null
            }
        }
    }

    fun shutdown() {
        executor.shutdownNow()
        bitmapCache.evictAll()
    }

    class PageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rootLayout: LinearLayout = view.findViewById(R.id.pageRootLayout)
        val headerBar: LinearLayout = view.findViewById(R.id.pageHeaderBar)
        val surahTitle: TextView = view.findViewById(R.id.pageHeaderSurah)
        val pageBadge: TextView = view.findViewById(R.id.pageHeaderNumber)
        val juzTitle: TextView = view.findViewById(R.id.pageHeaderJuz)
        val pageImage: ImageView = view.findViewById(R.id.pageImageView)
        val loadingBar: ProgressBar = view.findViewById(R.id.pageLoadingProgress)
        val dividerLine: View = view.findViewById(R.id.pageSeamlessDivider)
        var boundPosition: Int = -1
    }
}
