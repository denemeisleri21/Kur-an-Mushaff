package com.kuranokuma.mushaf

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.max
import kotlin.math.min

class ZoomableRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : RecyclerView(context, attrs, defStyleAttr) {

    var scaleFactor: Float = 1.0f
        private set
    private val minScale = 0.85f
    private val maxScale = 3.2f

    private var panX = 0f
    private var lastTouchX = 0f
    private var activePointerId = MotionEvent.INVALID_POINTER_ID

    var isHorizontalLocked: Boolean = false
    var isHorizontalPanLocked: Boolean
        get() = isHorizontalLocked
        set(value) {
            isHorizontalLocked = value
        }

    var onCenterTapListener: (() -> Unit)? = null
    var onCenterSingleTap: (() -> Unit)?
        get() = onCenterTapListener
        set(value) {
            onCenterTapListener = value
        }

    var onZoomChangedListener: ((Int) -> Unit)? = null
    var onZoomChanged: ((Float) -> Unit)? = null

    /**
     * Ekran döndürüldüğünde (Dikey <-> Yatay) veya RecyclerView boyutu değiştiğinde
     * gerçek genişlik ve yüksekliği anında bildirir.
     */
    var onViewportSizeChanged: ((Int, Int) -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val prevScale = scaleFactor
                scaleFactor = max(minScale, min(maxScale, scaleFactor * detector.scaleFactor))
                if (prevScale != scaleFactor) {
                    clampPanX()
                    notifyZoomChanged()
                    invalidate()
                }
                return true
            }
        }
    )

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                val w = width.toFloat()
                val h = height.toFloat()
                if (w > 0 && h > 0) {
                    if (e.x in (w * 0.14f)..(w * 0.86f) && e.y in (h * 0.14f)..(h * 0.86f)) {
                        onCenterTapListener?.invoke()
                        return true
                    }
                }
                return false
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                scaleFactor = if (scaleFactor > 1.15f) 1.0f else 1.75f
                clampPanX()
                notifyZoomChanged()
                invalidate()
                return true
            }
        }
    )

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        clampPanX()
        if (w > 0 && h > 0 && (w != oldw || h != oldh)) {
            onViewportSizeChanged?.invoke(w, h)
        }
    }

    private fun notifyZoomChanged() {
        onZoomChangedListener?.invoke((scaleFactor * 100).toInt())
        onZoomChanged?.invoke(scaleFactor)
    }

    fun setZoomPercent(percent: Int) {
        scaleFactor = max(minScale, min(maxScale, percent / 100f))
        clampPanX()
        notifyZoomChanged()
        invalidate()
    }

    fun stepZoom(delta: Float) {
        scaleFactor = max(minScale, min(maxScale, scaleFactor + delta))
        clampPanX()
        notifyZoomChanged()
        invalidate()
    }

    fun zoomIn() {
        setZoomPercent(((scaleFactor * 100).toInt() + 15).coerceAtMost(300))
    }

    fun zoomOut() {
        setZoomPercent(((scaleFactor * 100).toInt() - 15).coerceAtLeast(85))
    }

    private fun clampPanX() {
        if (scaleFactor <= 1.0f) {
            panX = 0f
            return
        }
        val maxPan = (width * (scaleFactor - 1.0f)) / 2f
        panX = panX.coerceIn(-maxPan, maxPan)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        gestureDetector.onTouchEvent(e)

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = e.x
                activePointerId = e.getPointerId(0)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && scaleFactor > 1.02f && !isHorizontalLocked) {
                    val pointerIndex = e.findPointerIndex(activePointerId)
                    if (pointerIndex != -1) {
                        val x = e.getX(pointerIndex)
                        val dx = x - lastTouchX
                        panX += dx
                        clampPanX()
                        invalidate()
                        lastTouchX = x
                    }
                } else {
                    val pointerIndex = e.findPointerIndex(activePointerId)
                    if (pointerIndex != -1) {
                        lastTouchX = e.getX(pointerIndex)
                    }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val pointerIndex = e.actionIndex
                val pointerId = e.getPointerId(pointerIndex)
                if (pointerId == activePointerId) {
                    val newPointerIndex = if (pointerIndex == 0) 1 else 0
                    lastTouchX = e.getX(newPointerIndex)
                    activePointerId = e.getPointerId(newPointerIndex)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activePointerId = MotionEvent.INVALID_POINTER_ID
            }
        }
        return super.onTouchEvent(e)
    }

    override fun dispatchDraw(canvas: Canvas) {
        canvas.save()
        val cx = width / 2f
        val cy = height / 2f
        canvas.translate(panX, 0f)
        canvas.scale(scaleFactor, scaleFactor, cx, cy)
        super.dispatchDraw(canvas)
        canvas.restore()
    }
}
